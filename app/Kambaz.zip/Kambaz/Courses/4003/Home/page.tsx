"use client";

import CS1234Modules from "../Modules/page";

const CS1234Home = () => {
  return (
    <div className="home-container">
      <CS1234Modules />
    </div>
  );
};

export default CS1234Home;