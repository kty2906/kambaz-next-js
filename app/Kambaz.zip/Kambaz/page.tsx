import { redirect } from "next/dist/client/components/navigation";

export default function DashboardPage() {
 redirect("./Dashboard");
}