import { redirect } from "next/dist/client/components/navigation";

export default function CoursesPage() {
 redirect("Kambaz/Courses/1234/Modules");
}